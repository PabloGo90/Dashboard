﻿using System.ComponentModel.DataAnnotations;

namespace KeanuAnalyzer.Models;
public class Analisis
{
    [Key]
    public int Id { get; set;}
    
    [Required]
    public Usuario UsuarioAnalista { get; set; }
    // public string Imagen64{ get; set; }
    public List<Accion> Acciones { get; set; }
    public List<Sentimiento> Sentimientos { get; set; }
    public List<Vestimenta> Vestimentas { get; set; }


    public Analisis()
    {
        this.UsuarioAnalista = new Usuario();
        this.Acciones = new List<Accion>();
        this.Sentimientos = new List<Sentimiento>();
        this.Vestimentas = new List<Vestimenta>();
        // this.Imagen64 = string.Empty;
    }
}
