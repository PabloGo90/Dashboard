﻿using System.ComponentModel.DataAnnotations;
namespace KeanuAnalyzer.Models;
public class Accion
{
    [Key]
    public int Id { get; set;}
    [Required]
    public string AccionQueEstaRealizando { get; set;} = "";
    public string DondeOQue { get; set;} = "";

}
