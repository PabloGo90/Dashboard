﻿using System.ComponentModel.DataAnnotations;
namespace KeanuAnalyzer.Models;
public class Vestimenta
{
    [Key]
    public int Id { get; set;}
    [Required]
    public string Prenda { get; set; } = "";
    public string Color { get; set; } = "";
    public bool EsFormal { get; set; }
    public bool EsAbrigado { get; set; }

}
