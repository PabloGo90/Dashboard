﻿using System.ComponentModel.DataAnnotations;
namespace KeanuAnalyzer.Models;
public class Sentimiento
{
    [Key]
    public int Id { get; set;}
    [Required]
    public string SentimientoQueExpresa { get; set;} = "";
    [Range(1,10)]
    public int intensidad { get; set; }

}
