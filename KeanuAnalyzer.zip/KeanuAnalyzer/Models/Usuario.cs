﻿using System.ComponentModel.DataAnnotations;
namespace KeanuAnalyzer.Models;
public class Usuario
{
    [Key]
    public int Id { get; set; }
    [Required]
    [MaxLength(100, ErrorMessage = "Nombre muy largo")]
    public string Nombre { get; set; } = "";
    public string Correo {get; set; } = "";
    public int Edad {get; set; }    
}
