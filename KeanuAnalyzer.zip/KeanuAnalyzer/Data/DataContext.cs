﻿using Microsoft.EntityFrameworkCore;
using KeanuAnalyzer.Models;

namespace KeanuAnalyzer.Data;

public class DataContext : DbContext
{
    public DbSet<Analisis> Analises{ get; set; }
    public DbSet<Accion> Acciones{ get; set; }
    public DbSet<Sentimiento> Sentimientos{ get; set;}
    public DbSet<Usuario> Usuarios{ get; set; }
     public DbSet<Vestimenta> Vestimentas{ get; set;}
    public string DbPath { get; }

    //https://learn.microsoft.com/en-us/ef/core/get-started/overview/first-app?tabs=netcore-cli
    
    public DataContext()
    {
        var folder = Environment.SpecialFolder.LocalApplicationData;
        var path = Environment.GetFolderPath(folder);
        DbPath = System.IO.Path.Join(path, "keanu.db");
    }

    // The following configures EF to create a Sqlite database file in the
    // special "local" folder for your platform.
    protected override void OnConfiguring(DbContextOptionsBuilder options)
        => options.UseSqlite($"Data Source={DbPath}");
}
