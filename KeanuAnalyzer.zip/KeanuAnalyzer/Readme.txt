dotnet add package Microsoft.EntityFrameworkCore.Sqlite
dotnet tool install --global dotnet-ef
dotnet add package Microsoft.EntityFrameworkCore.Design

--EF crea migracion y crea/actualiza base de datos
dotnet ef migrations add InitialCreate
--EF crea actualiza base de datos
dotnet ef database update
--EF cuando se quiere aplicar un cambio (se debe ejecutar update despues)
dotnet ef migrations add descripciondecambio


FLUJO
1- Busca imagen desde api 
2- boton realiza analisis clic
3- muestra formulario
    campos de usuario con buscar por nombre
        crea si no existe
3.1- etapa vestimenta
    llena formulario (cada item un postback)
3.2- etapa accion
    llena formulario (cada item un postback)
...
4- Permite ir y volver
5- guardar