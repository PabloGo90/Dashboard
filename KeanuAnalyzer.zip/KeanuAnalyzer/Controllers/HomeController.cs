﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using KeanuAnalyzer.Models;
using System.Linq;
using KeanuAnalyzer.Data;
using System.Net;


namespace KeanuAnalyzer.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;
    private readonly IHttpClientFactory _httpClientFactory;

    public HomeController(ILogger<HomeController> logger, IHttpClientFactory httpClientFactory)
    {
        _logger = logger;
        _httpClientFactory = httpClientFactory;
    }

    public IActionResult Index()
    {
        // Analisis analisis = new Analisis() { Imagen64 = await this.OnGetKeanu() };


        return View(new Analisis());
    }

    public IActionResult Privacy()
    {
        using var db = new DataContext();
        List<Accion> accion = new List<Accion>();
        Usuario usuario = new Usuario();


        usuario = new Usuario() { Nombre = "user", Correo = "Correo@coreo", Edad = 22 };
        accion.Add(new Accion() { AccionQueEstaRealizando = "mirando", DondeOQue = "a la derecha" });
        // Note: This sample requires the database to be created before running.
        Console.WriteLine($"Database path: {db.DbPath}.");

        // Create
        Console.WriteLine("Inserting a analisis");
        db.Add(new Analisis { Acciones = accion, UsuarioAnalista = usuario });
        db.SaveChanges();

        // Read
        Console.WriteLine("Querying for a blog");
        var blog = db.Usuarios.First();

        Console.WriteLine(db.Usuarios.First().Nombre);

        // Update
        // Console.WriteLine("Updating the blog and adding a post");
        // blog.Url = "https://devblogs.microsoft.com/dotnet";
        // blog.Posts.Add(
        //     new Post { Title = "Hello World", Content = "I wrote an app using EF Core!" });
        // db.SaveChanges();

        // Delete
        // Console.WriteLine("Delete the blog");
        // db.Remove(blog);
        // db.SaveChanges();

        return View();
    }

    // No se puede acceder de esta forma ya que api o permite
    // public async Task<string> OnGetKeanu()
    // {
    //     var httpClient = _httpClientFactory.CreateClient("KeanuApi");
    //     var httpResponseMessage = await httpClient.GetAsync("350/500");
    //     if (httpResponseMessage.IsSuccessStatusCode)
    //     {
    //         var content = await httpResponseMessage.Content.ReadAsStringAsync();
    //         return content;
    //     }

    //     return "";
    // }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
