﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace KeanuAnalyzer.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Usuarios",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Nombre = table.Column<string>(type: "TEXT", maxLength: 100, nullable: false),
                    Correo = table.Column<string>(type: "TEXT", nullable: false),
                    Edad = table.Column<int>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Usuarios", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Analises",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    UsuarioAnalistaId = table.Column<int>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Analises", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Analises_Usuarios_UsuarioAnalistaId",
                        column: x => x.UsuarioAnalistaId,
                        principalTable: "Usuarios",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Acciones",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    AccionQueEstaRealizando = table.Column<string>(type: "TEXT", nullable: false),
                    DondeOQue = table.Column<string>(type: "TEXT", nullable: false),
                    AnalisisId = table.Column<int>(type: "INTEGER", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Acciones", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Acciones_Analises_AnalisisId",
                        column: x => x.AnalisisId,
                        principalTable: "Analises",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "Sentimientos",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    SentimientoQueExpresa = table.Column<string>(type: "TEXT", nullable: false),
                    intensidad = table.Column<int>(type: "INTEGER", nullable: false),
                    AnalisisId = table.Column<int>(type: "INTEGER", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Sentimientos", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Sentimientos_Analises_AnalisisId",
                        column: x => x.AnalisisId,
                        principalTable: "Analises",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "Vestimentas",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Prenda = table.Column<string>(type: "TEXT", nullable: false),
                    Color = table.Column<string>(type: "TEXT", nullable: false),
                    EsFormal = table.Column<bool>(type: "INTEGER", nullable: false),
                    EsAbrigado = table.Column<bool>(type: "INTEGER", nullable: false),
                    AnalisisId = table.Column<int>(type: "INTEGER", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Vestimentas", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Vestimentas_Analises_AnalisisId",
                        column: x => x.AnalisisId,
                        principalTable: "Analises",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_Acciones_AnalisisId",
                table: "Acciones",
                column: "AnalisisId");

            migrationBuilder.CreateIndex(
                name: "IX_Analises_UsuarioAnalistaId",
                table: "Analises",
                column: "UsuarioAnalistaId");

            migrationBuilder.CreateIndex(
                name: "IX_Sentimientos_AnalisisId",
                table: "Sentimientos",
                column: "AnalisisId");

            migrationBuilder.CreateIndex(
                name: "IX_Vestimentas_AnalisisId",
                table: "Vestimentas",
                column: "AnalisisId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Acciones");

            migrationBuilder.DropTable(
                name: "Sentimientos");

            migrationBuilder.DropTable(
                name: "Vestimentas");

            migrationBuilder.DropTable(
                name: "Analises");

            migrationBuilder.DropTable(
                name: "Usuarios");
        }
    }
}
